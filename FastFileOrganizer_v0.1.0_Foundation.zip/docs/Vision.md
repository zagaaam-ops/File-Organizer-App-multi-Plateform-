# Vision

Build the fastest workflow-oriented file organizer.